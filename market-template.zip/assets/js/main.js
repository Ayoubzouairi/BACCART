
const $ = (sel, root=document)=>root.querySelector(sel);
const $$ = (sel, root=document)=>Array.from(root.querySelectorAll(sel));

const i18n = {
  en: {
    search_placeholder: "Search products...",
    add_to_cart: "Add to Cart",
    price: "Price",
    featured: "Featured",
    cart: "Cart",
    checkout: "Checkout",
    empty: "Your cart is empty.",
    quantity: "Qty",
    total: "Total",
    remove: "Remove",
    shop_now: "Shop now",
    categories: "Categories",
  },
  ar: {
    search_placeholder: "ابحث عن المنتجات...",
    add_to_cart: "أضف للسلة",
    price: "السعر",
    featured: "مميّز",
    cart: "السلة",
    checkout: "الدفع",
    empty: "سلتك فارغة.",
    quantity: "الكمية",
    total: "الإجمالي",
    remove: "حذف",
    shop_now: "تسوّق الآن",
    categories: "الفئات",
  }
};

const Lang = {
  get() { return localStorage.getItem("lang") || "ar"; },
  set(v){ localStorage.setItem("lang", v); location.reload(); }
}

async function getProducts(){
  const res = await fetch("products.json");
  return res.json();
}

const Cart = {
  key: "cart.v1",
  read(){ return JSON.parse(localStorage.getItem(this.key) || "[]"); },
  write(items){ localStorage.setItem(this.key, JSON.stringify(items)); },
  add(id, qty=1){
    const items = this.read();
    const found = items.find(i=>i.id===id);
    if(found){ found.qty += qty; } else { items.push({id, qty}); }
    this.write(items);
    badge();
  },
  remove(id){
    const items = this.read().filter(i=>i.id!==id);
    this.write(items);
    badge();
  },
  update(id, qty){
    const items = this.read();
    const it = items.find(i=>i.id===id);
    if(it){ it.qty = Math.max(1, qty); this.write(items); }
  },
  clear(){ this.write([]); badge(); }
};

function formatPrice(v){ return new Intl.NumberFormat(undefined, {style:'currency', currency:'MAD'}).format(v); }

function badge(){
  const count = Cart.read().reduce((a,b)=>a+b.qty,0);
  const el = $("#cart-badge");
  if(el) el.textContent = count>0? count : "0";
}

document.addEventListener("DOMContentLoaded", badge);

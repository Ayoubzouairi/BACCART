from fastapi import FastAPI, WebSocket
from pydantic import BaseModel
import httpx, asyncio, time

app = FastAPI()
BINANCE_K = 'https://api.binance.com/api/v3/klines'

class SignalResponse(BaseModel):
    symbol: str
    signal: str
    confidence: float
    ts: int

async def fetch_klines(symbol='BTCUSDT', interval='1m', limit=200):
    params = {'symbol':symbol, 'interval':interval, 'limit':limit}
    async with httpx.AsyncClient() as c:
        r = await c.get(BINANCE_K, params=params, timeout=10)
        r.raise_for_status()
        data = r.json()
    closes = [float(k[4]) for k in data]
    return closes

def ema(series, span):
    alpha = 2/(span+1)
    ema = []
    for i, v in enumerate(series):
        if i==0:
            ema.append(v)
        else:
            ema.append(alpha*v + (1-alpha)*ema[-1])
    return ema

@app.get('/health')
async def health():
    return {'status':'ok'}

@app.get('/price/{symbol}')
async def price(symbol: str):
    closes = await fetch_klines(symbol, '1m', limit=1)
    return {'symbol':symbol, 'price':closes[-1]}

@app.get('/signals/{symbol}', response_model=SignalResponse)
async def signals(symbol: str):
    closes = await fetch_klines(symbol, '1m', limit=200)
    e12 = ema(closes, 12)
    e26 = ema(closes, 26)
    if e12[-1] > e26[-1] and e12[-2] <= e26[-2]:
        sig = 'BUY'
        conf = min(0.99, max(0.01, (e12[-1]-e26[-1]) / abs(e26[-1]) ))
    elif e12[-1] < e26[-1] and e12[-2] >= e26[-2]:
        sig = 'SELL'
        conf = min(0.99, max(0.01, (e26[-1]-e12[-1]) / abs(e12[-1]) ))
    else:
        sig = 'HOLD'
        conf = 0.5
    return SignalResponse(symbol=symbol, signal=sig, confidence=conf, ts=int(time.time()*1000))

@app.websocket('/ws/{symbol}')
async def websocket_endpoint(websocket: WebSocket, symbol: str):
    await websocket.accept()
    try:
        while True:
            sig = await signals(symbol)
            await websocket.send_json(sig.dict())
            await asyncio.sleep(5)
    except Exception:
        await websocket.close()

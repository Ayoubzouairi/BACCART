CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  username TEXT UNIQUE,
  password_hash TEXT,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE historical_prices (
  id BIGSERIAL PRIMARY KEY,
  symbol TEXT,
  ts BIGINT,
  open NUMERIC, high NUMERIC, low NUMERIC, close NUMERIC, volume NUMERIC
);

CREATE TABLE signals_log (
  id BIGSERIAL PRIMARY KEY,
  symbol TEXT,
  ts BIGINT,
  signal TEXT,
  confidence REAL,
  meta JSONB
);

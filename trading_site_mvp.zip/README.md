# Trading Site MVP — Package (Arabic / Darija)

هاد المشروع هو نسخة MVP باش تبني موقع تحليل وsignals.

**شنو فيه:**
- frontend (React) بسيط: `frontend/`
- backend (FastAPI): `backend/`
- docker-compose لتشغيل محلي
- DB schema وملفات مساعدة

## كيفاش تشغّل محلي (بنسخة Docker)
1. تأكد أنك منصّب Docker و docker-compose.
2. فك هاد الملف zip فـمّا مكان تناسبك.
3. فالجذر ديال المشروع شغّل:

   ```
   docker-compose up --build
   ```
4. Backend غادي يولي خدام على `http://localhost:8000`.
   - Health: `http://localhost:8000/health`
   - Example signals: `http://localhost:8000/signals/BTCUSDT`
5. Frontend: ممكن تخدّم React app لوّحدها أو تفتح الملفات فـIDE وتشغّل `npm install` و `npm start` داخل `frontend/`.

## ملاحظات
- هاد الكود هو MVP تعليمي rule-based لsignals (EMA cross).
- باش تخدم production خاص تدير إعدادات الأمان، كلمات السر، SSL، وتهيئة DB.
- إذا بغيتي، نقدر نعدّليك إصدار مهيأ للنشر على VPS (Ubuntu + Nginx).

------------------------------------------------

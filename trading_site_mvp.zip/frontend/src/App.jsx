import React, {useEffect, useState} from 'react';

export default function App(){
  const [signals, setSignals] = useState([]);
  const [symbol, setSymbol] = useState('BTCUSDT');

  useEffect(()=>{ fetchSignals(); const i = setInterval(fetchSignals, 10000); return ()=>clearInterval(i); }, [symbol]);

  async function fetchSignals(){
    try{
      const res = await fetch(`http://localhost:8000/signals/${symbol}`);
      const data = await res.json();
      setSignals(prev=>[data, ...prev].slice(0,50));
    }catch(e){console.error(e)}
  }

  return (
    <div style={{padding:20, fontFamily:'Arial, sans-serif'}}>
      <header style={{marginBottom:16}}>
        <h1>TradingSite MVP</h1>
        <div style={{marginTop:8}}>
          <label>Symbol: </label>
          <input value={symbol} onChange={e=>setSymbol(e.target.value)} style={{border:'1px solid #ccc', padding:4}} />
        </div>
      </header>

      <main style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:16}}>
        <section>
          <div id="tv-widget" style={{height:400, border:'1px solid #eee', padding:8}}>
            <p>Chart widget هنا - TradingView script محطوط فـindex.html. باش تبين الشارت استعمل الوثائق ديال TradingView widget.</p>
          </div>

          <div style={{marginTop:16}}>
            <h2>Backtester (مثال مبسّط)</h2>
            <p>هنا تقدر تضيف واجهة لاختيار range وتشغيل backtest.</p>
          </div>
        </section>

        <aside>
          <h2>Signals feed</h2>
          <ul style={{listStyle:'none', padding:0}}>
            {signals.map((s, idx)=> (
              <li key={idx} style={{padding:8, borderBottom:'1px solid #eee'}}>
                <div><strong>{s.signal}</strong> — {s.symbol}</div>
                <div>confidence: {Number(s.confidence).toFixed(2)}</div>
                <div>time: {new Date(s.ts).toLocaleString()}</div>
              </li>
            ))}
          </ul>
        </aside>
      </main>
    </div>
  )
}
